import pygame
import math
import time 
from pygame import mixer

grid_size = 60
grid_number = 10

pygame.init()
pygame.font.init()
screen = pygame.display.set_mode((grid_size*grid_number + 400, grid_size*grid_number))
pygame.display.set_caption('Game')

pygame.mixer.music.load('bgm.mp3')
pygame.mixer.music.play(-1)   

icon = pygame.image.load('sf_icon.jfif')
game_name = pygame.image.load('game_name.png').convert_alpha()
game_name = pygame.transform.scale(game_name, (500, 150))  

background = pygame.image.load('background.png').convert_alpha()
background = pygame.transform.scale(background, (600, 600))  
background_image = pygame.image.load('background_image.jpg').convert_alpha()
background_image = pygame.transform.scale(background_image, (1000, 600)) 
button_1 = pygame.image.load('button_1.png').convert_alpha()
button_1 = pygame.transform.scale(button_1, (100, 43)) 
button_2 = pygame.image.load('button_2.png').convert_alpha()
button_2 = pygame.transform.scale(button_2, (220, 40)) 
button_3 = pygame.image.load('button_3.png').convert_alpha()
button_3 = pygame.transform.scale(button_3, (80, 40)) 
button_4 = pygame.transform.scale(button_3, (80, 40)) 
button_5 = pygame.image.load('button_5.png').convert_alpha()
button_5 = pygame.transform.scale(button_5, (80, 40)) 
button_6 = pygame.image.load('button_6.png').convert_alpha()
button_6 = pygame.transform.scale(button_6, (80, 40)) 
tutorial = pygame.image.load('tutorial.png').convert_alpha()
market1_text = pygame.image.load('market1_text.png').convert_alpha()
market1_text = pygame.transform.scale(market1_text, (250, 30)) 
market2_text = pygame.image.load('market2_text.png').convert_alpha()
market2_text = pygame.transform.scale(market2_text, (250, 30)) 
market3_text = pygame.image.load('market3_text.png').convert_alpha()
market3_text = pygame.transform.scale(market3_text, (250, 30)) 
market4_text = button_4 = pygame.transform.scale(button_3, (50, 30)) 
tutorial = pygame.transform.scale(tutorial, (600, 600)) 
story_1 = pygame.image.load('story_1.png').convert_alpha()
story_1 = pygame.transform.scale(story_1, (600, 400)) 
nasus = pygame.image.load('nasus.png').convert_alpha()
nasus = pygame.transform.scale(nasus, (60, 60)) 
player = pygame.image.load('player.png').convert_alpha()
player = pygame.transform.scale(player, (55, 55))  
enemy_1 = pygame.image.load('enemy_1.png').convert_alpha()
enemy_1 = pygame.transform.scale(enemy_1, (55, 55))  
block = pygame.image.load('block.png').convert_alpha()
old_man = pygame.image.load('old_man.png').convert_alpha()
old_man = pygame.transform.scale(old_man, (55, 55))  
old_man2 = pygame.transform.scale(old_man, (100, 100)) 
block = pygame.image.load('block.png').convert_alpha()
block = pygame.transform.scale(block, (60, 60))  
lava = pygame.image.load('lava.png').convert_alpha()
lava= pygame.transform.scale(lava, (60, 600))  
sword_1 = pygame.image.load('sword_1.png').convert_alpha()
sword_1 = pygame.transform.scale(sword_1, (50, 50))  
coin_1 = pygame.image.load('coin_1.png').convert_alpha()
coin_1 = pygame.transform.scale(coin_1, (50, 50))  
staircase = pygame.image.load('staircase.png').convert_alpha()
staircase = pygame.transform.scale(staircase, (55, 55))  
key_1 = pygame.image.load('key_1.png').convert_alpha()
key_1 = pygame.transform.scale(key_1, (55, 55))  
key_2 = pygame.image.load('key_2.png').convert_alpha()
key_2 = pygame.transform.scale(key_2, (55, 55)) 
key_3 = pygame.image.load('key_3.png').convert_alpha()
key_3 = pygame.transform.scale(key_3, (55, 55)) 
gate_1 = pygame.image.load('gate_1.png').convert_alpha()
gate_1 = pygame.transform.scale(gate_1, (60, 60)) 
gate_2 = pygame.image.load('gate_2.png').convert_alpha()
gate_2 = pygame.transform.scale(gate_2, (60, 60)) 
gate_3 = pygame.image.load('gate_3.png').convert_alpha()
gate_3 = pygame.transform.scale(gate_3, (60, 60)) 
enemy_2 = pygame.image.load('enemy_2.png').convert_alpha()
enemy_2 = pygame.transform.scale(enemy_2, (55, 55))  
enemy_3 = pygame.image.load('enemy_3.png').convert_alpha()
enemy_3 = pygame.transform.scale(enemy_3, (55, 55)) 
enemy_4 = pygame.image.load('enemy_4.png').convert_alpha()
enemy_4 = pygame.transform.scale(enemy_4, (55, 55))  
enemy_5 = pygame.image.load('enemy_5.png').convert_alpha()
enemy_5 = pygame.transform.scale(enemy_5, (55, 55))  
shield_1 = pygame.image.load('shield_1.png').convert_alpha()
shield_1 = pygame.transform.scale(shield_1, (50, 50))  
hp_potion = pygame.image.load('hp_potion.png').convert_alpha()
hp_potion = pygame.transform.scale(hp_potion, (50, 50)) 
exp_potion = pygame.image.load('exp_potion.png').convert_alpha()
exp_potion = pygame.transform.scale(exp_potion, (50, 50)) 
boss_1 = pygame.image.load('boss_1.png').convert_alpha()
boss_1 = pygame.transform.scale(boss_1, (120, 120)) 
npc_1 = pygame.image.load('npc_1.png').convert_alpha()
npc_1 = pygame.transform.scale(npc_1, (55, 55)) 
npc_1b = pygame.transform.scale(npc_1, (100, 100)) 
market = pygame.image.load('market.png').convert_alpha()
market = pygame.transform.scale(market, (120, 60))
tobesaved_1 = pygame.image.load('tobesaved_1.png').convert_alpha()
tobesaved_1 = pygame.transform.scale(tobesaved_1, (48, 48)) 
msg_box = pygame.image.load('msg_box.png').convert_alpha()
msg_box = pygame.transform.scale(msg_box, (600, 150)) 

font_1 = pygame.font.SysFont('comicsansms', 15)
font = pygame.font.SysFont('comicsansms', 25)
font2 = pygame.font.SysFont('comicsansms', 40)    
dialogue_warn1 = font.render("You are not strong enough", True, (240, 248, 255))    
dialogue_warn2 = font_1.render("This person doesn't want to talk to you", True, (240, 248, 255))    
dialogue_0a = font_1.render("The moment you step into the land of Jason, you feel a pain in my skull", True, (240, 248, 255))
dialogue_0b = font_1.render("and its not long until I realised that you have problems. Just when you're trying", True, (240, 248, 255))
dialogue_0c = font_1.render("to find the way out of this place, a boy named comes out", True, (240, 248, 255))    
dialogue_0d = font_1.render("The boy looks at you menancingly, and before you know it", True, (240, 248, 255))
dialogue_0e = font_1.render("he is gone", True, (240, 248, 255))  
dialogue_0f = font_1.render("You look around, feeling very scared, only thing you see is some staircase", True, (240, 248, 255))
dialogue_0g = font_1.render("You decide: why no walk up there", True, (240, 248, 255))    
dialogue_1 = font_1.render("What is this place... I need to get out of here...", True, (240, 248, 255)) 
dialogue_4 = font.render("Does this thing ever end?", True, (240, 248, 255))    
dialogue_5a = font_1.render("Beware of the next floor kid, I heard there is a monster", True, (240, 248, 255))    
dialogue_5b = font_1.render("guarding the exit of this dungeon. Once you go in, there's no", True, (240, 248, 255))    
dialogue_5c = font_1.render("coming out. Make sure you are fully prepared before entering", True, (240, 248, 255))
dialogue_6a = font_1.render("It seems so empty in here, was that old man lying...", True, (240, 248, 255))
dialogue_6b = font_1.render("Oh myy, what is that.. Am I really strong enough to take that thing down..", True, (240, 248, 255))
dialogue_6c = font_1.render("Damn, I'm stronger than I thought..", True, (240, 248, 255))
dialogue_6d = font_1.render("But I really need to get out of here..", True, (240, 248, 255))
dialogue_7 = font_1.render("To be continued...", True, (240, 248, 255))

msg_box_xy = (200, 450)

old_man_x = [440]
old_man_y = [2580]

market_x = [260]
market_y = [2460]

lava_x = [200, 260, 320, 380, 560, 620, 680, 740, ]
lava_y = [-600, -600, -600, -600,  -600, -600, -600, -600]

block_x = [440, 500, 440, 500, 380, 380, 380, 380, 380, 380, 380, 380, 560, 560, 560, 560, 560, 560, 560, 560, 260, 620, 680,
           260, 320, 380, 440, 500, 560, 620, 620, 620, 620, 620, 620, 260, 320, 380, 500, 560, 380, 500,
           260, 320, 380, 560, 620, 680, 260, 320, 380, 560, 620, 680, 500, 500, 500, 320, 320, 380, 440, 500, 560, 620,
           260, 320, 380, 560, 620, 680, 380, 500, 380, 500, 260, 380, 500, 380, 500, 380, 500, 500, 560, 620, 620, 620, 620,
           680, 620, 560, 500, 380, 380, 380, 680, 620, 560, 500, 500, 500, 500, 380, 320, 260, 380, 380, 260,
           260, 320, 380, 560, 620, 680, 380, 380, 380, 380, 380, 380, 560, 560, 560, 560, 560, 560]
block_y = [-600, -600, -60, -60, 120, 180, 240, 300, 360, 420, 480, 540, 120, 180, 240, 300, 360, 420, 480, 540, 300, 120, 300,
           720, 720, 720, 720, 720, 720, 720, 780, 840, 900, 1020, 1080, 900, 900, 900, 900, 900, 840, 840,
           1620, 1620, 1620, 1620, 1620, 1620, 1440, 1440, 1440, 1440, 1440, 1440, 1620, 1440, 1560, 1260, 1320, 1320, 1320, 1320, 1320, 1320,
           1920, 1920, 1920, 1920, 1920, 1920, 1980, 1980, 2040, 2040, 2100, 2100, 2100, 2160, 2160, 2220, 2220, 1920, 2220, 2220, 1980, 2040, 2100,
           2640, 2640, 2640, 2640, 2640, 2460, 2520, 2520, 2520, 2520, 2520, 2700, 2760, 2880, 2700, 2700, 2700, 2820, 2760, 2820,
           3420, 3420, 3420, 3420, 3420, 3420, 3060, 3120, 3180, 3240, 3300, 3360, 3060, 3120, 3180, 3240, 3300, 3360]

exp_to_level = [100, 120, 150, 190, 250, 320, 400, 500, 650, 800, 1000, 1200, 1500, 1900, 2500] 

sword_1_x = [680, 260, 260, 440, 560, 620]
sword_1_y = [480, 1080, 1560, 1260, 2100, 2700]

shield_1_x = [260, 260, 680, 680, 620]
shield_1_y = [480, 780, 1560, 1320, 2880]

coin_1_x = [680, 620]
coin_1_y = [2040, 2460]

enemy_1_x = [440, 500, 440, 500, 620, 680, 440, 560, 260, 380, 560, 560, 560]
enemy_1_y = [60, 60, 120, 120, 480, 420, 660, 660, 1020, 1020, 2880, 2760, 2700]
enemy_hp = [60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60, 60]

enemy_2_x = [320, 500, 320, 680, 620, 320, 380, 680, 620]
enemy_2_y = [360, 660, 1080, 180, 240, 960, 1680, 1380, 1380]
enemy_2_hp = [100, 100, 100, 100, 100, 100, 100, 100, 100]

enemy_3_x = [560, 440, 380, 380, 560, 560, 320, 680, 560, 620, 560, 320]
enemy_3_y = [960, 840, 1500, 1560, 1500, 1560, 780, 1260, 1380, 2160, 2160, 2760]
enemy_3_hp = [180, 180, 180, 180, 180, 180, 180, 180, 180, 180, 180, 180]

enemy_4_x = [560, 620, 320, 500, 260, 500, 560]
enemy_4_y = [1860, 360, 1680, 1260, 1320, 2460, 2460]
enemy_4_hp = [300, 300, 300, 300, 300, 300, 300]

enemy_5_x = [320, 560]
enemy_5_y = [2160, 2820]
enemy_5_hp = [450, 450]

boss_1_x = [-1560]
boss_1_y = [3120]
boss_1_hp = [1000]

npc_1_x = [260, 260]
npc_1_y = [1980, 240]

tobesaved_1_x = [260]
tobesaved_1_y = [1680]

hp_potion_x = [320, 260, 620, 440, 260, 440, 620, 620]
hp_potion_y = [1020, 1500, 1260, 1380, 2160, 2460, 2760, 2820]

exp_potion_x = [560, 560, 560, 560, 680, 680, 680, 680, 680]
exp_potion_y = [840, 780, 1260, 2040, 2460, 2880, 2820, 2760, 2700]

staircase_up_x = [260, 680, 260, 680, 440, 260, 500]
staircase_up_y = [60, 1080, 1260, 1980, -360, 2880, 3060]

staircase_down_x = [260, 680, 260, 680]
staircase_down_y = [660, 1680, 1860, 2580]

border_x = []
border_y = []

gate_1_x = [320, 620, 440, 500, 320, 680, 380, 500, 500, 440, 500, 320]
gate_1_y = [300, 960, 1620, 2280, 2100, 120, 780, 780, 1500, 2520, 2820, 2820]

gate_2_x = [440, 440, 380, 620, 680, 380]
gate_2_y = [900, 1440, 2280, 300, 2220, 2580]

gate_3_x = [440]
gate_3_y = [2640]

key_1_x = [320, 380, 680, 620, 680, 260, 620, 260, 320, 440]
key_1_y = [480, 1080, 1500, 180, 240, 960, 1860, 2040, 1980, 2760]

key_2_x = [260, 680, 620, 560, 440, 260]
key_2_y = [840, 1860, 1560, 1980, 2700, 2760]

class Button: 
    def __init__(self, x, y, image):
        self.image = image
        self.rect = self.image.get_rect()
        self.rect.topleft = (x, y)
        self.clicked = False
        
    def draw(self):
        action = False
        pos = pygame.mouse.get_pos()
        
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                self.clicked = True
                action = True

        if pygame.mouse.get_pressed()[0] == 0:
            self.clicked = False       
    
        screen.blit(self.image, (self.rect.x, self.rect.y))
        return action
    
    def check_collide(self):
        action = False
        pos = pygame.mouse.get_pos()
    
        if self.rect.collidepoint(pos):
            if pygame.mouse.get_pressed()[0] == 1 and self.clicked == False:
                self.clicked = True
                action = True
    
        if pygame.mouse.get_pressed()[0] == 0:
            self.clicked = False  
        return action
    
button_1 = Button(310, 280, button_1)
button_2 = Button(310, 340, button_2)
button_3 = Button(310, 400, button_3)
button_4 = Button(850, 500, button_4)
button_5 = Button(800, 500, button_5)
button_6 = Button(150, 500, button_6)
button_msg = Button(200, 450, msg_box)

progression = 0
progress = 0
nasus_x = -560
nasus_y = 360

game_start = False
tutorial_enabled = False
story_start = False

coins = 10

player_x = 500
player_y = 360
player_hp = 500
player_damage = 20
player_defense = 5
player_exp = 0
player_level = 0

player_movement = False
player_collision = False
player_level_up = False
npc_1_collision2 = False
market_collision_2 = False

yes_no = False
warning_1 = False
warning_2 = False

enemy_damage = 14
enemy_defense = 2

enemy2_damage = 25
enemy2_defense = 5

enemy_3_damage = 30
enemy_3_defense = 5

enemy_4_damage = 40
enemy_4_defense = 20

enemy_5_damage = 45
enemy_5_defense = 35

boss_1_damage = 60
boss_1_defense = 40

vel = 60
player_state = 0
stage = -1
key1_number = 1
key2_number = 1
key3_number = 1

def append_border(x, y):
    for i in range(1, grid_number):
        border_x.append(grid_size*i + 140)
        border_x.append(140 + grid_size * grid_number)
        border_x.append(grid_size*i + 200)
        border_x.append(200)  

        border_y.append(0)
        border_y.append(i*grid_size-60)
        border_y.append(grid_size * grid_number - 60)
        border_y.append(i*grid_size)      

append_border(grid_size, grid_number)

def spawn_enemy(x, y, enemy):
    for i in range(len(x)):
        screen.blit(enemy, (x[i], y[i] - stage * 600))

def draw_item(x, y, item):
    for i in range (len(x)):
        screen.blit(item, (x[i], y[i] - stage * 600))
        
def draw_border(x, y):
    for i in range(len(border_x)):
        screen.blit(block, (border_x[i], border_y[i]))  

def draw_block(x, y, block):
    for i in range(len(x)):
        screen.blit(block, (x[i], y[i] - stage * 600))    
        
def check_collision(player_x, player_y, x, y):
    for i in range(len(x)):
        distance = math.sqrt(math.pow(player_x - x[i], 2) + (math.pow(player_y - (y[i] - 600 * stage), 2)))
        if distance < 30:
            return True

def check_border_collision(player_x, player_y, x, y):
    for i in range(len(x)):
        distance = math.sqrt(math.pow(player_x - x[i], 2) + (math.pow(player_y - (y[i]), 2)))
        if distance < 30:
            return True

def checking_collision(player_x, player_y, enemy_1_x, enemy_1_y):
    distance = math.sqrt(math.pow(player_x - enemy_1_x, 2) + (math.pow(player_y - (enemy_1_y - 600 * stage), 2)))
    if distance < 40:    
        return True


#def print_dialogue(x, font):
    #for i in range(len(x)):
        #a = 330 + i*2
        #line = 0
        #text = font.render(str(x[i]), True, (240,248,255))
        
        #if a > 750:
            #line += 1
        #time.sleep(0.01)
        #screen.blit(text, (330 + i*10 - line*420, 470 + line*30))
        #pygame.display.update()

def checking_item_collision(player_x, player_y, item_1_x, item_1_y):
    distance = math.sqrt(math.pow(player_x - item_1_x, 2) + (math.pow(player_y - (item_1_y - 600 * stage), 2)))
    if distance < 30:
        loot_sound = mixer.Sound('loot_sound.mp3')
        loot_sound.play()             
        return True
        
def combat(player_health, player_damage, player_defense, enemy_health, enemy_damage, enemy_defense):
    global player_movement
    count = 0
    hp = player_health
    hp2 = enemy_health
    a = player_damage - enemy_defense
    if enemy_damage - player_defense > 0:
        b = enemy_damage - player_defense
    else:
        b = 0
        
    if a < 0:
        return False

    elif count == 0:
        for i in range (1, 100):
            player_health -= b

            if player_health <= 0:
                player_health = hp
                enemy_health = hp2
                return False
            
            enemy_health -= player_damage - enemy_defense
            if enemy_health <= 0:
                count += 1   
                break

    if count == 1:
        player_health = hp
        enemy_health = hp2         
        for i in range (1, 100):
            player_health -= b
            hit_enemy = mixer.Sound('sound_1.mp3')
            hit_enemy.play()             
            time.sleep(0.02)           
            print('Player HP:', player_health)

            if player_health <= 0:
                player_health = hp
                enemy_health = hp2
                return False

            enemy_health -= player_damage - enemy_defense
            print('Enemy HP:', enemy_health)
            if enemy_health <= 0:
                enemy_slained = mixer.Sound('sound_2.mp3')
                enemy_slained.play()         
                return True, player_health             

run = True

while run:    
    #print(player_x, player_y)
    screen.blit(background_image, (0, 0))
    
    if game_start == False:
        screen.blit(game_name, (260, 50))
        
        if button_1.draw():
            story_start = True 
            
        if button_2.draw():
            tutorial_enabled = True
            
        if button_3.draw():
            run = False       
            
        if story_start:
            screen.blit(background_image, (0,0))
            screen.blit(story_1, (200, 40))
            if button_5.draw():
                game_start = True
                player_movement = True
                    
            elif button_6.draw():
                story_start = False
        
        if tutorial_enabled:
            screen.blit(background_image, (0,0))
            screen.blit(tutorial, (200, 0))
            if button_4.draw():
                tutorial_enabled = False      
    
            
    if game_start == True:
        screen.blit(background, (200, 0))
        draw_border(border_x, border_y)
        draw_block(block_x, block_y, block)
        screen.blit(player, (player_x, player_y)) 
        if stage == -1:
            draw_block(lava_x, lava_y, lava)
            screen.blit(nasus, (nasus_x, nasus_y))
            if player_x > 500 or player_x < 440:
                player_collision = True
            
            if progression < 3: 
                player_movement = False
                screen.blit(msg_box, (200, 450))
                screen.blit(dialogue_0a, (215, 470))
                screen.blit(dialogue_0b, (215, 500))
                screen.blit(dialogue_0c, (215, 530))
                
                if button_msg.check_collide():
                    nasus_x += 1000            
                    progress += 1
                    
                if progression == 1:
                    screen.blit(msg_box, (200, 450))
                    screen.blit(dialogue_0d, (215, 470))
                    screen.blit(dialogue_0e, (215, 500))     
                    
                if progression == 2:
                    screen.blit(msg_box, (200, 450))
                    screen.blit(dialogue_0f, (215, 470))  
                    screen.blit(dialogue_0g, (215, 500))  
                
        if progression == 3:
            player_movement = True
                    
                
        draw_item(sword_1_x, sword_1_y, sword_1)
        spawn_enemy(enemy_1_x, enemy_1_y, enemy_1)
        spawn_enemy(enemy_2_x, enemy_2_y, enemy_2)
        spawn_enemy(enemy_3_x, enemy_3_y, enemy_3)
        spawn_enemy(enemy_4_x, enemy_4_y, enemy_4)
        spawn_enemy(enemy_5_x, enemy_5_y, enemy_5)
        spawn_enemy(boss_1_x, boss_1_y, boss_1)
        draw_item(staircase_up_x, staircase_up_y, staircase)
        draw_item(staircase_down_x, staircase_down_y, staircase)
        draw_item(gate_1_x, gate_1_y, gate_1)
        draw_item(gate_2_x, gate_2_y, gate_2)
        draw_item(gate_3_x, gate_3_y, gate_3)
        draw_item(shield_1_x, shield_1_y, shield_1)
        draw_item(key_1_x, key_1_y, key_1)
        draw_item(key_2_x, key_2_y, key_2)
        draw_item(hp_potion_x, hp_potion_y, hp_potion)
        draw_item(exp_potion_x, exp_potion_y, exp_potion)
        draw_item(npc_1_x, npc_1_y, npc_1)
        draw_item(tobesaved_1_x, tobesaved_1_y, tobesaved_1)
        draw_item(coin_1_x, coin_1_y, coin_1)
        draw_item(market_x, market_y, market)
        draw_item(old_man_x, old_man_y, old_man)
                    
        floor_text = font.render("Floor: ", True, (240,248,255))
        floor2_text = font.render(str(stage + 1), True, (240,248,255))
        screen.blit(floor_text, (20, 20))  
        screen.blit(floor2_text, (125, 20))                   
        
        hp_text = font.render("Health: ", True, (240,248,255))
        hp2_text = font.render(str(player_hp), True, (240,248,255))
        screen.blit(hp_text, (20, 100))  
        screen.blit(hp2_text, (125, 100))
    
        attack_text = font.render("Attack: ", True, (240,248,255))
        attack2_text = font.render(str(player_damage), True, (240,248,255))
        screen.blit(attack2_text, (125, 150))      
        screen.blit(attack_text, (20, 150))     
    
        coin_text = font.render("Coins: ", True, (240,248,255))
        coin2_text = font.render(str(coins), True, (240,248,255))
        screen.blit(coin2_text, (125, 200))      
        screen.blit(coin_text, (20, 200))  
    
        defense_text = font.render("Defense: ", True, (240,248,255))
        defense2_text = font.render(str(player_defense), True, (240,248,255))
        screen.blit(defense2_text, (125, 250))      
        screen.blit(defense_text, (20, 250))    
        
        level_text = font.render("Level: ", True, (240,248,255))
        level2_text = font.render(str(player_level), True, (240,248,255))
        screen.blit(level2_text, (125, 300))      
        screen.blit(level_text, (20, 300))     
    
        exp_percent = player_exp / (exp_to_level[player_level]/100)
        if exp_percent >= 100:
            player_exp -= exp_to_level[player_level]
            player_level += 1
            player_level_up = True
        
        if player_level_up == True:
            player_damage += 3
            player_defense += 2
            player_hp += 50
            player_level_up = False
        
        #print(exp_percent)
        player_expbar = pygame.Rect(80, 357, 100, 25)  
        player_expbar_filled = pygame.Rect(80, 357, exp_percent, 25)  
        exp_text = font.render("Exp: ", True, (240,248,255))
        pygame.draw.rect(screen, (255, 0, 0), player_expbar)
        pygame.draw.rect(screen, (0, 255, 0), player_expbar_filled)
        screen.blit(exp_text, (20, 350))        
    
        key_text = font2.render(str(key1_number), True, (240,248,255))    
        screen.blit(key_1, (820, 50))
        screen.blit(key_text, (900, 50))
        
        key2_text = font2.render(str(key2_number), True, (240,248,255))   
        screen.blit(key_2, (820, 130))
        screen.blit(key2_text, (900, 130))  
        
        key3_text = font2.render(str(key3_number), True, (240,248,255))   
        screen.blit(key_3, (820, 210))
        screen.blit(key3_text, (900, 210))  
        
        market1_text = font.render("20 gold for 100hp: ", True, (240,248,255))
        market2_text = font.render("20 gold for 4 attack: ", True, (240,248,255))
        market3_text = font.render("20 gold for 2 defense : ", True, (240,248,255))
        
        
        button_7 = Button(250, 475, market1_text)
        button_8 = Button(250, 515, market2_text)
        button_9 = Button(250, 555, market3_text)
        button_10 = Button(700, 560, market4_text)
    
    block_collision = check_collision(player_x, player_y, block_x, block_y)
    border_collision = check_border_collision(player_x, player_y, border_x, border_y)       
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP and player_movement == True:
                player_y -= vel
                player_state = 'up'

            if event.key == pygame.K_DOWN and player_movement == True:
                player_y += vel
                player_state = 'down'

            if event.key == pygame.K_RIGHT and player_movement == True:
                player_x += vel
                player_state = 'right'

            if event.key == pygame.K_LEFT and player_movement == True:
                player_x -= vel
                player_state = 'left'
                
            for i in range(len(npc_1_x)):
                npc_1_collision = checking_collision(player_x, player_y, npc_1_x[i], npc_1_y[i])
                if npc_1_collision == True and coins < 35:
                    warning_2 = True
                                   
                elif npc_1_collision == True and coins >= 35:
                    player_movement = False
                    yes_no = True          
                    if event.key == pygame.K_RSHIFT:
                        coins -= 35
                        player_exp += 300
                        npc_1_x[i] += 2000
                        npc_1_collision == False
                        player_movement = True
                        yes_no = False
                        
                    elif event.key == pygame.K_LSHIFT:
                        player_x += 60
                        npc_1_collision == False
                        player_movement = True  
                        yes_no = False
                    

    if yes_no == True:
        screen.blit(msg_box, (200, 450)) 
        screen.blit(npc_1b, (210, 475))
        npc_text = font.render("Do you want to trade 35 coins for 300xp", True, (240,248,255))
        npc_text2 = font.render("RSHIFT for yes, LSHIFT for no",  True, (240,248,255))
        screen.blit(npc_text, (330, 470))     
        screen.blit(npc_text2, (330, 520))
    
    for i in range(len(staircase_up_x)):
        staircase_up_collision = checking_collision(player_x, player_y, staircase_up_x[i], staircase_up_y[i])

        if staircase_up_collision == True:
            stage += 1
            progress += 1
            if player_x > 620:
                player_x -= 60
            else:
                player_x += 60
                
    for i in range(len(staircase_down_x)):
        staircase_down_collision = checking_collision(player_x, player_y, staircase_down_x[i], staircase_down_y[i])

        if staircase_down_collision == True:
            stage -= 1
            progress -= 1
            if player_y < 420:
                player_y += 60
            else:
                player_y -= 60    
                
    for i in range(len(sword_1_x)):
        sword_collision = checking_item_collision(player_x, player_y, sword_1_x[i], sword_1_y[i])
        
        if sword_collision == True:
            player_damage += 5
            sword_1_x[i] += 2000

            
    for i in range(len(hp_potion_x)):
        hp_potion_collision = checking_item_collision(player_x, player_y, hp_potion_x[i], hp_potion_y[i])
        
        if hp_potion_collision == True:
            player_hp += 200
            hp_potion_x[i] += 2000  
            
    for i in range(len(exp_potion_x)):
        exp_potion_collision = checking_item_collision(player_x, player_y, exp_potion_x[i], exp_potion_y[i])
        
        if exp_potion_collision == True:
            player_exp += 200
            exp_potion_x[i] += 2000         
            
    for i in range(len(key_1_x)):
        key_1_collision = checking_item_collision(player_x, player_y, key_1_x[i], key_1_y[i])
        
        if key_1_collision == True:
            key_1_x[i] += 2000  
            key1_number += 1
            
    for i in range(len(key_2_x)):
        key_2_collision = checking_item_collision(player_x, player_y, key_2_x[i], key_2_y[i])
        
        if key_2_collision == True:
            key_2_x[i] += 2000  
            key2_number += 1    
            
    for i in range(len(shield_1_x)):
        shield_1_collision = checking_item_collision(player_x, player_y, shield_1_x[i], shield_1_y[i])
        
        if shield_1_collision == True:
            player_defense += 5
            shield_1_x[i] += 2000      
            
    for i in range(len(market_x)):
        market_collision = checking_collision(player_x, player_y, market_x[i] + 30, market_y[i])
        if market_collision == True and coins < 20:
            player_collision = True
            print('Come back when you have more gold')
        elif market_collision == True and coins >= 20:
            market_collision_2 = True
            market_collision = False
            player_collision = True
            player_movement = False
            
    if market_collision_2 == True and coins > 20:
        screen.blit(msg_box, (200, 450))
        if button_7.draw():
            player_hp += 100
            coins -= 20
            player_movement = True
        if button_8.draw():
            player_damage += 4
            coins -= 20
            player_movement = True
        if button_9.draw():
            player_defense += 2
            coins -= 20
            player_movement = True
        if button_10.draw():
            market_collision_2 == False
     
    for i in range(len(old_man_x)):       
        old_man_collision = checking_collision(player_x, player_y, old_man_x[i], old_man_y[i])
        
        if old_man_collision == True:
            player_collision = True
            progression += 1
                
    if block_collision == True or border_collision == True:
        player_collision = True
        
    for i in range(len(coin_1_x)):
        coin_1_collision = checking_item_collision(player_x, player_y, coin_1_x[i], coin_1_y[i])
        
        if coin_1_collision == True:
            coin_1_x[i] += 2000  
            coins += 10   

    for i in range(len(gate_1_x)):
        gate1_collision = checking_collision(player_x, player_y, gate_1_x[i], gate_1_y[i])

        if gate1_collision == True:
            if key1_number > 0:
                opening_gate = mixer.Sound('opening_gate.mp3')
                opening_gate.play()                 
                key1_number -= 1
                gate_1_x[i] = -2000
            else:
                player_collision =  True  
                
    for i in range(len(gate_2_x)):
        gate2_collision = checking_collision(player_x, player_y, gate_2_x[i], gate_2_y[i])

        if gate2_collision == True:
            if key2_number > 0:
                opening_gate = mixer.Sound('opening_gate.mp3')
                opening_gate.play()                 
                key2_number -= 1
                gate_2_x[i] = -2000
            else:
                player_collision =  True        
                
    for i in range(len(gate_3_x)):
        gate3_collision = checking_collision(player_x, player_y, gate_3_x[i], gate_3_y[i])

        if gate3_collision == True:
            if key3_number > 0:
                opening_gate = mixer.Sound('opening_gate.mp3')
                opening_gate.play()                 
                key3_number -= 1
                gate_3_x[i] = -2000
            else:
                player_collision =  True         

    
    for i in range(len(enemy_1_x)):
        collision = checking_collision(player_x, player_y, enemy_1_x[i], enemy_1_y[i])

        if collision == True:  
            win_fight = combat(player_hp, player_damage, player_defense, enemy_hp[i], enemy_damage, enemy_defense)

            if win_fight == False:
                player_collision = True
                warning_1 = True
                continue     

            elif win_fight[0] == True:
                player_hp = win_fight[1]
                coins += 3
                player_exp += 10
                enemy_1_x[i] = -2000


    for i in range(len(enemy_2_x)):
        collision = checking_collision(player_x, player_y, enemy_2_x[i], enemy_2_y[i])

        if collision == True:                  
            win_fight = combat(player_hp, player_damage, player_defense, enemy_hp[i], enemy2_damage, enemy2_defense)

            if win_fight == False:
                player_collision = True
                warning_1 = True
                continue             

            elif win_fight[0] == True:
                player_hp = win_fight[1]
                enemy_2_x[i] += 2000
                coins += 5
                player_exp += 15

           
        for i in range(len(enemy_3_x)):
            collision = checking_collision(player_x, player_y, enemy_3_x[i], enemy_3_y[i])
    
            if collision == True:                  
                win_fight = combat(player_hp, player_damage, player_defense, enemy_3_hp[i], enemy_3_damage, enemy_3_defense)
    
                if win_fight == False:
                    player_collision = True
                    warning_1 = True
                    continue             
    
                elif win_fight[0] == True:
                    player_hp = win_fight[1]
                    coins += 7
                    player_exp += 20
                    enemy_3_x[i] = -2000
                
        for i in range(len(enemy_4_x)):
            collision = checking_collision(player_x, player_y, enemy_4_x[i], enemy_4_y[i])
    
            if collision == True:                  
                win_fight = combat(player_hp, player_damage, player_defense, enemy_4_hp[i], enemy_4_damage, enemy_4_defense)
    
                if win_fight == False:
                    warning_1 = True
                    player_collision = True
                    continue             
    
                elif win_fight[0] == True:
                    player_hp = win_fight[1]
                    coins += 10
                    player_exp += 30
                    enemy_4_x[i] = -2000
                    
        for i in range(len(enemy_5_x)):
            collision = checking_collision(player_x, player_y, enemy_5_x[i], enemy_5_y[i])
    
            if collision == True:                  
                win_fight = combat(player_hp, player_damage, player_defense, enemy_5_hp[i], enemy_5_damage, enemy_5_defense)
    
                if win_fight == False:
                    player_collision = True
                    warning_1 = True
                    continue             
    
                elif win_fight[0] == True:
                    player_hp = win_fight[1]
                    coins += 15
                    player_exp += 50
                    enemy_5_x[i] = -2000  
        
        for i in range(len(boss_1_x)):
            boss_1_collision = checking_collision(player_x, player_y, boss_1_x[i] + 30, boss_1_y[i] + 60)  
            if boss_1_collision == True:
                win_fight = combat(player_hp, player_damage, player_defense, boss_1_hp[i], boss_1_damage, boss_1_defense)
                
                if win_fight == False:
                    player_collision = True
                    print('You are not strong enough')
                    continue             
    
                elif win_fight[0] == True:
                    player_hp = win_fight[1]
                    coins += 50
                    player_exp += 100
                    boss_1_x[i] = -2000              

    if player_x < 260 or player_x > 680 or player_y < 60 or player_y > 480:
        player_collision == True
    
    if player_collision == True:
        if player_state == 'right':
            player_x -= vel
            player_collision = False
        if player_state == 'left':
            player_x += vel
            player_collision = False
        if player_state == 'up':
            player_y += vel
            player_collision = False
        if player_state == 'down':
            player_y -= vel      
            player_collision = False

    
    if player_x < 200 or player_x > 800 or player_y < 0 or player_y > 600:
        run = False
    
    if progress > progression:
        progression = progress
    
    if progression == 4:
        player_movement = False
        screen.blit(msg_box, msg_box_xy)
        screen.blit(dialogue_1, (230, 500))
        if button_msg.check_collide():
            progress += 1    
            player_movement = True
    
    if progression == 8:
        player_movement = False
        screen.blit(msg_box, msg_box_xy)
        screen.blit(dialogue_4, (230, 500))
        if button_msg.check_collide():
            progress += 1    
            player_movement = True        
        
    if progression == 11:
        player_movement = False
        screen.blit(msg_box, msg_box_xy) 
        screen.blit(old_man2, (210, 475))
        screen.blit(dialogue_5a, (330, 480))
        screen.blit(dialogue_5b, (330, 510))
        screen.blit(dialogue_5c, (330, 540))
        if button_msg.check_collide():
            progress += 1    
            old_man_x[0] += 2000
            player_movement = True     
            
    if progression == 13:
        player_movement = False
        screen.blit(msg_box, msg_box_xy) 
        screen.blit(dialogue_6a, (230, 500))
        if button_msg.check_collide():
            progress += 1    
            player_movement = True    
            
    if progression == 14 and player_x == 380:
        boss_1_x[0] += 2000
        progress += 1
    
    if progression == 15 and player_x == 440:
        player_movement = False
        screen.blit(msg_box, msg_box_xy)         
        screen.blit(dialogue_6b, (230, 500))
        if button_msg.check_collide():
            progress += 1    
            player_movement = True   
    
    if progression == 16:
        player_movement = False
        screen.blit(msg_box, msg_box_xy)         
        screen.blit(dialogue_6c, (230, 480))
        screen.blit(dialogue_6d, (230, 515))
        if button_msg.check_collide():
            progress += 1    
            player_movement = True   
            
    if progression == 18:
        player_movement = False
        screen.blit(msg_box, msg_box_xy)        
        screen.blit(dialogue_7, (230, 480))           
           
    if warning_1 == True:
        screen.blit(msg_box, msg_box_xy) 
        screen.blit(dialogue_warn1, (230, 500))
        if button_msg.check_collide():
            warning_1 = False
        
    if warning_2 == True:
        screen.blit(msg_box, msg_box_xy) 
        screen.blit(dialogue_warn2, (230, 500)) 
        if button_msg.check_collide():
            warning_2 = False
        
    pygame.display.update()